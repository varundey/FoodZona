A Pen created at CodePen.io. You can find this one at http://codepen.io/rpora/pen/wBaLPp.

 [Work In Progress] A little smooth scrolling JS module.
Accept GSAP with scrollTo plug or jquery   (default : jQuery)
You can customize the behavior when scroll occurs ( class attributions, etc )

There is room for optimization! :)