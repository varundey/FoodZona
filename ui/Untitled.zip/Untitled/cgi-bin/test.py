#!/usr/bin/python
import cgi, cgitb 
cgitb.enable()
print "Content-Type: text/html\n"
for i in range(10):
	print i
