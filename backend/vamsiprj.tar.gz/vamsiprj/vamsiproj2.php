<html>
<body>
<center>
<p>
<b>
<h2>
"Our Products are Genuine and Contentful! <br>
 We Hope you Enjoy Shopping with us." <br>
</h2>
</b>
</p>
<a href="http://127.0.0.1/vamsiprj/stocks.php">
	<button type="button">
		STOCKS
	</button>
</a>

<a href="http://127.0.0.1/vamsiprj/sell(1).php">
	<button type="button">
		BUY
	</button>
</a>
<?php
session_start();
$_SESSION['total'] = 0;
?>
<a href="http://127.0.0.1/vamsiprj/vamsiproj.php">
<button type="button"> EXIT </button>
</center>
</a>
<body background="green.jpg">
</body>
</html>


